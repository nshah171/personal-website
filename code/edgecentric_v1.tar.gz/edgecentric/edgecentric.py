import numpy as np
import subprocess as sp
import sys

from scipy.spatial.distance import cdist
from collections import defaultdict
from operator import itemgetter

def kldivergence(p,q):
	p = np.array(p);
	q = np.array(q);
	val = np.sum(np.where(p != 0,(p) * np.log2(p / q), 0));
	if np.isnan(val):
		return 0;
	return val;

if len(sys.argv) < 3:
        sys.exit("need arguments: python edgecentric.py filename.txt [unip|bip] [undir|dir] attrtype1 attrtype2 attrtype3\nattrtypes can be 'cat', 'num' or 'time' for categorical/numerical/timestamp attributes respectively");
else:
        nattrs = len(sys.argv) - 4;

relation_fn = sys.argv[1];
relation_nparts = sys.argv[2];
relation_direction = sys.argv[3];
relation_attrtypes = sys.argv[4:];

attrmins = [np.Inf for x in range(0,nattrs)];
attrmaxes = [-np.Inf for x in range(0,nattrs)];

relation_data = np.genfromtxt(relation_fn);

leftview = defaultdict(lambda: [[] for x in range(0,nattrs)]);
rightview = defaultdict(lambda: [[] for x in range(0,nattrs)]);

for rowid in range(0,np.shape(relation_data)[0]):
        leftid = relation_data[rowid,0];
        rightid = relation_data[rowid,1];
        for t in range(0,nattrs):
                attrval = relation_data[rowid,t+2];
                if relation_attrtypes[t] != "time":
                        if attrval < attrmins[t]:
                                attrmins[t] = attrval;
                        if attrval > attrmaxes[t]:
                                attrmaxes[t] = attrval;
                leftview[leftid][t].append(attrval);
                if relation_direction != "dir":
                        rightview[rightid][t].append(attrval);

n_left_samples = dict();
n_right_samples = dict();

for key in leftview.keys():
        n_left_samples[key] = len(leftview[key][0]);

if relation_direction != "dir":
        for key in rightview.keys():
                n_right_samples[key] = len(rightview[key][0]);

for t in range(0,nattrs):
        if relation_attrtypes[t] == "time":
                for key in leftview.keys():
                        leftview[key][t] = np.diff(sorted(leftview[key][t])).tolist();
			if len(leftview[key][t]) == 0:
				leftview[key][t] = [-1];
                        minval = min(leftview[key][t]);
                        maxval = max(leftview[key][t]);
                        if minval < attrmins[t]:
                                attrmins[t] = minval;
                        if maxval > attrmaxes[t]:
                                attrmaxes[t] = maxval;
		if relation_direction != "dir":
			attrmins[t] = [attrmins[t], np.Inf];
			attrmaxes[t] = [attrmaxes[t], -np.Inf];
			for key in rightview.keys():
				rightview[key][t] = np.diff(sorted(rightview[key][t])).tolist();
				if len(rightview[key][t]) == 0:
					rightview[key][t] = [-1];
				minval = min(rightview[key][t]);
				maxval = max(rightview[key][t]);
				if minval < attrmins[t][1]:
					attrmins[t][1] = minval;
				if maxval > attrmaxes[t][1]:
					attrmaxes[t][1] = maxval;

left_scores = defaultdict(list);
right_scores = defaultdict(list);

tot_left_scores = defaultdict(int);
tot_right_scores = defaultdict(int);

for t in range(0,nattrs):
	print t
	if relation_attrtypes[t] == "cat":
		left_bin_markers = range(int(attrmins[t]), int(attrmaxes[t]) + 2);
		right_bin_markers = left_bin_markers;
	elif relation_attrtypes[t] == "num":
		if attrmaxes[t] >= 10 * attrmins[t]:  #20 bins default for numerical attributes
			if attrmins[t] <= 0:
				attrmins[t] = 0.1; #allowing logarithm
			left_bin_markers = [0];
			left_bin_markers.extend(np.logspace(np.log10(attrmins[t]) - 0.01, np.log10(attrmaxes[t]) + 0.01, num = 20).tolist()); #padding for machine error
			right_bin_markers = left_bin_markers;
		else:
			left_bin_markers = np.linspace(attrmins[t], attrmaxes[t], 20).tolist();
			right_bin_markers = left_bin_markers;
	elif relation_attrtypes[t] == "time":
		if attrmaxes[t][0] >= 10 * attrmins[t][0]: #20 bins default for temporal attributes
			if attrmins[t][0] <= 0:
				attrmins[t][0] = 0.1; #allowing logarithm
			left_bin_markers = [0];
			left_bin_markers.extend(np.logspace(np.log10(attrmins[t][0]) - 0.01, np.log10(attrmaxes[t][0]) + 0.01, num = 20).tolist()); #padding for machine error
		else:
			left_bin_markers = np.linspace(attrmins[t][0], attrmaxes[t][0], num = 20).tolist();
		
		if attrmaxes[t][1] >= 10 * attrmins[t][1]:
			if attrmins[t][1] <= 0:
				attrmins[t][1] = 0.1; #allowing logarithm
			right_bin_markers = [0];
			right_bin_markers.extend(np.logspace(np.log10(attrmins[t][1]) - 0.01, np.log10(attrmaxes[t][1]) + 0.01, num = 20).tolist()); #padding for machine error
		else:
			right_bin_markers = np.linspace(attrmins[t][1], attrmaxes[t][1], num = 20).tolist();
	
	print left_bin_markers
	print right_bin_markers
	#cluster left view
	fout = open("__tmppoints",'w');
	points = defaultdict(list);
	tmppts = [];
	for key, val in leftview.iteritems():
		bin_probs = np.histogram(val[t], bins = left_bin_markers)[0];
		bin_probs = (1.0*bin_probs / sum(bin_probs)).tolist();
		points[key] = bin_probs;
		tmppts.append(bin_probs);
		if not np.isnan(bin_probs[0]):
			fout.write(' '.join([str(x) for x in bin_probs]) + '\n');
	
	fout.close();
	
	res = sp.Popen("./kmeans kmeans -create_universe true -k 1 -method blacklist -max_leaf_size 128 -min_box_width 0.1 -cutoff_factor 0.5 -max_iter 30 -num_splits 6 -max_ctrs 100 -in __tmppoints -save_ctrs __tmpctrs -printclusters __tmpclust".split(' '), stdout=sp.PIPE, stderr=sp.PIPE);
	out, err = res.communicate();
	print err
	
	clust_ctrs = np.genfromtxt('__tmpctrs', delimiter = ',');
	for i in range(0, len(clust_ctrs)):
		tmpctr = clust_ctrs[i] + 0.001;
		tmpctr = 1.0*tmpctr / sum(tmpctr);
		clust_ctrs[i] = tmpctr;
		
	sq_dist_mat = cdist(tmppts, clust_ctrs, 'euclidean');
	clustids = np.argmin(sq_dist_mat, axis=1)
	
	fout = open('__tmpclustids.txt','w');
	for g in clustids:
		fout.write(str(g) + '\n');
	
	fout.close();
	
	clust_props = np.histogram(clustids, bins = range(min(clustids), max(clustids) + 2))[0];
	clust_props = (1.0*clust_props / sum(clust_props)).tolist();
	
	res = sp.Popen(['mkdir','left' + str(t)], stdout=sp.PIPE, stderr=sp.PIPE);
	out, err = res.communicate();
	print err
	
	res = sp.Popen(' '.join(['mv','__tmp*','left'+str(t)]), shell = True, stdout=sp.PIPE, stderr=sp.PIPE);
	out, err = res.communicate();
	print err
	
	print clust_ctrs;
	print clust_props;
	
	for key in leftview.keys():
		exp_bits = 0;
		for i in range(0,len(clust_ctrs)):
			exp_bits += clust_props[i] * kldivergence(points[key], clust_ctrs[i]);
		exp_bits *= n_left_samples[key];
		left_scores[key].append(exp_bits);
		tot_left_scores[key] += exp_bits;
	
	print "left scores computed"
	
	#cluster right view
	if relation_direction != "dir":
		fout = open("__tmppoints",'w');
		points = defaultdict(list);
		tmppts = [];
		for key, val in rightview.iteritems():
			bin_probs = np.histogram(val[t], bins = right_bin_markers)[0];
			bin_probs = (1.0*bin_probs / sum(bin_probs)).tolist();
			points[key] = bin_probs;
			tmppts.append(bin_probs);
			if not np.isnan(bin_probs[0]):
				fout.write(' '.join([str(x) for x in bin_probs]) + '\n');
		
		fout.close();
		
		res = sp.Popen("./kmeans kmeans -create_universe true -k 1 -method blacklist -max_leaf_size 128 -min_box_width 0.1 -cutoff_factor 0.5 -max_iter 30 -num_splits 6 -max_ctrs 100 -in __tmppoints -save_ctrs __tmpctrs -printclusters __tmpclust".split(' '), stdout=sp.PIPE, stderr=sp.PIPE);
		out, err = res.communicate();
		print err
		
		clust_ctrs = np.genfromtxt('__tmpctrs', delimiter = ',');
		for i in range(0, len(clust_ctrs)):
			tmpctr = clust_ctrs[i] + 0.001;
			tmpctr = 1.0*tmpctr / sum(tmpctr);
			clust_ctrs[i] = tmpctr;

		sq_dist_mat = cdist(tmppts, clust_ctrs, 'euclidean');
		clustids = np.argmin(sq_dist_mat, axis=1)

		fout = open('__tmpclustids.txt','w');
		for g in clustids:
			fout.write(str(g) + '\n');
		
		fout.close();
		
		clust_props = np.histogram(clustids, bins = range(min(clustids), max(clustids) + 2))[0];
		clust_props = (1.0*clust_props / sum(clust_props)).tolist();
		
		res = sp.Popen("cat __tmpctrs".split(' '), stdout=sp.PIPE, stderr=sp.PIPE);
		out, err = res.communicate();
		print err
		clust_ctrs = [];
		for cluststr in out.rstrip().split('\n'):
			tmp = np.array([float(x) for x in cluststr.split(',')]) + 0.001;
			clust_ctrs.append((tmp / sum(tmp)).tolist());
		
		res = sp.Popen(['mkdir','right' + str(t)], stdout=sp.PIPE, stderr=sp.PIPE);
		out, err = res.communicate();
		print err
		
		res = sp.Popen(' '.join(['mv','__tmp*','right' + str(t)]), shell = True, stdout=sp.PIPE, stderr=sp.PIPE);
		out, err = res.communicate();
		print err
		
		print clust_ctrs;
		print clust_props;
		
		for key in rightview.keys():
			exp_bits = 0;
			for i in range(0, len(clust_ctrs)):
				exp_bits += clust_props[i] * kldivergence(points[key], clust_ctrs[i]);
			exp_bits *= n_right_samples[key];
			right_scores[key].append(exp_bits);
			tot_right_scores[key] += exp_bits;
		
		print "right scores computed"

sorted_left_scores = sorted(tot_left_scores.items(), key = itemgetter(1), reverse = True);
fout = open('left_scores.txt','w');
for key,val in sorted_left_scores:
	fout.write(str(key) + ' ' + str(val) + '\n');

fout.close();

if relation_direction != "dir":
	sorted_right_scores = sorted(tot_right_scores.items(), key = itemgetter(1), reverse = True);
	fout = open('right_scores.txt','w');
	for key,val in sorted_right_scores:
		fout.write(str(key) + ' ' + str(val) + '\n');
	
	fout.close();

print 'outputs written to *_scores.txt files'
