function [ scores, ordering, lastidx ] = node_attrib( inv1, inv2 )    

root_distances = sqrt(sum((sqrt(inv1) - sqrt(inv2)).^2,2));
[scores, ordering] = sort(root_distances,'descend');
lastidx = length(scores);

% For the brain graphs:
% return everything that has changed even a bit in descending order
idx_changed = scores > 0;
idx = length(idx_changed);

% runningtot = 0;
% scoresum = sum(scores);
% if scoresum == 0
% 	scores = [];
% 	ordering = [];
% 	lastidx = 0;
% 	return;
% end
% lastidx = 1;
% 
% for i = 1:numel(scores)
% 	if runningtot < 0.8
% 		runningtot = runningtot + (scores(i)/scoresum);
% 		lastidx = i;
% 	else
% 		break;
% 	end
% end

end




