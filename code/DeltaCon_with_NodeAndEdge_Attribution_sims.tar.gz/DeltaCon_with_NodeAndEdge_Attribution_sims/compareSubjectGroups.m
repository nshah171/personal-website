function [] = compareSubjectGroups(group1dir, nameGroup1, group2dir, nameGroup2)
%% INPUTS: 
% group1: directory where the brains of group 1 are saved
% group2: directory where the brains of group 2 are saved


%%
% Get the filenames in the folder of group 1 and group 2
group1 = getFilenamesInFolder(group1dir);
group2 = getFilenamesInFolder(group2dir);
group1Len = length(group1);
group2Len = length(group2);

% each row has the rankings of one comparison
% size: number of comparisons x cortical regions (70)
allRankings = zeros(group1Len*group2Len,70);
allNodeScores = zeros(group1Len*group2Len,70);

compCnt = 1;
for ii = 1 : group1Len
    for jj = 1 : group2Len
        % do all the pairwise comparisons and save the results
        fname1 = strcat(group1dir,'/',group1(ii));
        brain1 = load(fname1{1});
        brain1_sym = log10(brain1.fibergraph + brain1.fibergraph');
        brain1_sym(brain1_sym==-Inf) = 0;
        fname2 = strcat(group2dir,'/',group2(jj));
        brain2 = load(fname2{1});
        brain2_sym = log10(brain2.fibergraph + brain2.fibergraph');
        brain2_sym(brain2_sym==-Inf) = 0;
        [sim, simSTD, nodeCulprits, ~,~,~,nodeScores] = DeltaCon_brain_graphs('matFiles', 'naive', brain1_sym, brain2_sym, 0.1);
        % convert the nodeCulprits to a voting schema: for each of the
        % 70 nodes, save the rank it got during this comparison
        % (note: nodeCulprits has the node culprits ordered in decreasing
        % order of importance)
        allRankings(compCnt,1:length(nodeCulprits)) = nodeCulprits;
        allNodeScores(compCnt,1:length(nodeCulprits)) = nodeScores;
        compCnt = compCnt + 1
    end
end

% names of output files
rankingsOut = sprintf('allRankings_%s_%s.mat', nameGroup1, nameGroup2);
nodeScoresOut = sprintf('allNodeScores_%s_%s.mat', nameGroup1, nameGroup2);

save(rankingsOut, 'allRankings')
save(nodeScoresOut,'allNodeScores')



    %% 
    function [group] = getFilenamesInFolder(groupDir)
        d = dir(groupDir);
        group = {d.name};
        % ignore '.', '..', 'svn' etc.
        i = 1;
        while endswith(group(i), 'mat') == 0
            i = i + 1;
        end
        group = group(i:end);
    end



end


