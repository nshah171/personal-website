function [ scores, ordering ] = edge_attrib( A1, A2, culpritSet, allNodeOrdering, allNodeScores )    

if numel(culpritSet) == 0
	scores = [];
	ordering = [];
	return
end

[allNodeOrdering, I] = sort(allNodeOrdering);
allNodeScores = allNodeScores(I);

edgeScoreTable = [];

for i = 1:numel(culpritSet)
	srcNode = culpritSet(i);
	r = A2(srcNode,:) - A1(srcNode,:);
	for k = 1:numel(r)
		destNode = k;
		if r(k) == 1
                        allNodeScores(srcNode)
                        allNodeScores(destNode)
			edgeScore = allNodeScores(srcNode) + allNodeScores(destNode);
			edgeScoreTable = vertcat(edgeScoreTable,[srcNode destNode 1 edgeScore]);
		elseif r(k) == -1
			edgeScore = allNodeScores(srcNode) + allNodeScores(destNode);
			edgeScoreTable = vertcat(edgeScoreTable, [srcNode destNode -1 edgeScore]);
		end
	end
end

edgeScoreTableSorted = sortrows(edgeScoreTable,4);
edgeScoreTableSorted = flipud(edgeScoreTableSorted);

scores = full(edgeScoreTableSorted(:,4));
ordering = full(edgeScoreTableSorted(:,[1 2]));

end



