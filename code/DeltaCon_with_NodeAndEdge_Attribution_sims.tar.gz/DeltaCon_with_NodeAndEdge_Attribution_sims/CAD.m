function [node_scores] = CAD( datasetName, edgeFile1, edgeFile2 )
%function [anomalous_nodes, anomalous_edges] = CAD( datasetName, edgeFile1, edgeFile2 )
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Naive implementation for the paper:                                     %
%   Localizing anomalous changes in time-evolving graphs                  %
%   Kumar Sricharan, Kamalika Das                                         %
%   SIGMOD'14                                                             %
%                                                                         %
% Code by Danai Koutra                                                    %
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if nargin < 3
    disp('>>>> call: sparse_read_data_v2( datasetName, edgeFile1, edgeFile2 )');
else
    
    %% Load the edge files and create the corresponding adjacency matrices
    if strcmpi( datasetName, 'matFiles')
        A1 = edgeFile1;
        A2 = edgeFile2;
    else
        A1  = edgefile2matrix( edgeFile1 );
        A2 = edgefile2matrix( edgeFile2 );
    end
    
    if nargin < 6
        nodeCnt = max( size(A1,1), size(A2,2) );
    elseif nargin == 6
        nodeCnt = nodes;
    end
    A1(nodeCnt, nodeCnt) = 0;
    A2(nodeCnt, nodeCnt) = 0;
    
    C1 = computeCommuteTimes(A1);
    C2 = computeCommuteTimes(A2);

    %% Create the sparse degree-diagonal matrix
    DE = abs(A1-A2) .* abs(C1-C2);

    node_scores = sum(DE,2);


    %% Return the top anomalous edges
    %[sortedValues,sortIndex] = sort(DE(:),'descend');  %# Sort the values in
                                                  %#   descending order

    %maxIndex = sortIndex(1:290);  %# Get the top-5 most anomalous edges
    
    %% Return the top anomalous nodes (all nodes adjacent to edges)
    %[I,J] = ind2sub([size(A1,1),size(A1,1)],maxIndex);

    %anomalous_edges = [I,J];
    %anomalous_nodes = unique([I;J]);

    
end

end
