function [ scores, ordering, lastidx ] = node_attrib( inv1, inv2 )    

root_distances = sqrt(sum((sqrt(inv1) - sqrt(inv2)).^2,2));
[scores, ordering] = sort(root_distances,'descend');
lastidx = length(scores);

runningtot = 0;
scoresum = sum(scores);
if scoresum == 0
	scores = [];
	ordering = [];
	lastidx = 0;
	return;
end
lastidx = 1;

for i = 1:numel(scores)
	if runningtot < 0.8
		runningtot = runningtot + (scores(i)/scoresum);
		lastidx = i;
	else
		break;
	end
end

end



