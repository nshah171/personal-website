pts = [];

%generate 4 bivariate gaussians with random x/y centers.
for i = 1:4
	mu_x = randi(40);
	mu_y = randi(40);

	clust = randn(500,2);

	clust(:,1) = clust(:,1) + mu_x;
	clust(:,2) = clust(:,2) + mu_y;
	
	pts = [pts; clust];
end

%see the plot of 4 mv gaussians
plot(pts(:,1), pts(:,2), 'LineStyle','none','marker','.')

%store the distance matrix as P, and then compute A1 as exp(-P)
P = squareform(pdist(pts, 'euclidean'));
P = exp(-P);
A1 = P;

%generate random noise matrix R with low perturbation probability, and compute A2 as perturbed Q (P)
R = sprand(2000,2000,0.0001);
Q = P;
A2 = Q + ((R+R')/2);

[i,j,~] = find(R);
badedges = [];

%find the between-cluster edges that are considered 'bad' according to the CAD paper
for t = 1:numel(i)
	xclust = floor(i(t)./500);
	yclust = floor(j(t)./500);
	
	if xclust ~= yclust
		badedges = [badedges; i(t) j(t)];
	end
end

%mark the bad nodes as the ones that are bad according to CAD
badnodes = unique(badedges);

%create the vector w/ true labels
true_labels = sparse(2000,1);
true_labels(badnodes) = 1;

[~, ~, norder, ~, ~, ~, nis, ~] = DeltaCon('matFiles', 'naive', A1, A2, 0.1);

%compute the prediction vector for DeltaCon
dc_pred = sparse(2000,1);
for d = 1:numel(norder)
	dc_pred(norder(d)) = nis(d);
end

%compute the prediction vector for CAD
[cad_pred] = CAD('matFiles', A1, A2);

%run perfcurve for the ROC points and AUC info.
[dc_x,dc_y,dc_t,dc_auc] = perfcurve(true_labels,dc_pred,1);
[cad_x,cad_y,cad_t,cad_auc] = perfcurve(true_labels,cad_pred,1);

%print DeltaCon and CAD AUCs
dc_auc
cad_auc

%generate plots
plot(dc_x,dc_y,'color','blue')
hold on
plot(cad_x,cad_y,'color','red')

legend('DeltaCon','CAD');

xlabel('False Positive Rate');
ylabel('True Positive Rate');

title('ROC Curves for DeltaCon and CAD');

hold off


