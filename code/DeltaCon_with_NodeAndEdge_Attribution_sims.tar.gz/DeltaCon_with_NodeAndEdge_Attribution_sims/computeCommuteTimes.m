function [ C ] = computeCommuteTimes( A)  

    %% Create the sparse degree-diagonal matrix
    D = sparse( diag(sum(A,2)) );

    %% Get the Laplacian 
    L = D - A;

    % and the pseudo-inverse laplacian
    Lps = pinv(full(L));

    % Graph volume
    Vg = sum(sum(D));

    %% l_ii
    l = diag(Lps);
    Lii = repmat(l,1,length(l));

    % l_jj
    Ljj = repmat(l',length(l),1);
    
    %% compute the commute times
    C = Vg * (Lii + Ljj - 2 * Lps);

end
