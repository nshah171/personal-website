[sim, simSTD, norder, eorder, time, timeSTD] = DeltaCon('edge', 'naive', 'GRAPHS/B5.txt', 'GRAPHS/B5_mod.txt', 0.1)
[sim, simSTD, norder, eorder, time, timeSTD] = DeltaCon('edge', 'fast', 'GRAPHS/B5.txt', 'GRAPHS/B5.txt', 0.1)

% To run the CAD algorithm (SIGMOD'14, localizing anomalous changes)
[nodes,edges] = CAD('edge','GRAPHS/B5.txt', 'GRAPHS/eB5fig.txt')
