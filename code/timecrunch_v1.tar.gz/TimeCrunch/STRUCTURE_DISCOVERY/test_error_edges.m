function [ ] = test_error_edges(E)


for i = 1 : length(E)
    if E(i) < 0
        error('Negative number of 1s or 0s in the error matrix E...')
    end
end
    
end