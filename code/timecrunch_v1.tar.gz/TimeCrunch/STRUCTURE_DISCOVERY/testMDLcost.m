function [] = testMDLcost( mdlCost )

if mdlCost < 0 
    error('The MDL cost is negative...');
elseif isnan(mdlCost)
    error('The MDL cost is NaN...');
end

end