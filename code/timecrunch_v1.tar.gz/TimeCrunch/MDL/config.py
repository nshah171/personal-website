optModelZeroes = False;
optVerbosity = 1;
optDefaultError = 'TP';