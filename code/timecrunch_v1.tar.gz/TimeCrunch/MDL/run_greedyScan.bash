#!/bin/bash

time -p python2.7 greedyScan.py ../../data/WikiUserGraphs/lcrMediaWiki_wholeEdges.graph ../../code/slashburn/wikipedia_files/lcrMediaWiki_whole_SB_noStar3_orderedALL.model > OUTPUT_greedyScan_lcr_whole.out
time -p python2.7 greedyScan.py ../../data/WikiUserGraphs/chocMediaWiki_sentenceEdges.graph ../../code/slashburn/wikipedia_files/chocMediaWiki_sentence_SB_noStar3_orderedALL.model > OUTPUT_greedyScan_choc_sentence.out &
time -p python2.7 greedyScan.py ../../data/WikiUserGraphs/kievMediaWiki_wholeEdges.graph ../../code/slashburn/wikipedia_files/kievMediaWiki_whole_SB_noStar3_orderedALL.model > OUTPUT_greedyScan_kiev_whole.out
