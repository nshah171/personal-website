Contact: neilshah@cs.cmu.edu

** Code from paper "s-index: Towards Better Metrics for Quantifying Research Impact" by Neil Shah and Yang Song (http://arxiv.org/abs/1507.03650)

** Note that this is a preliminary and unpolished release.  A more accessible version will be uploaded shortly.  Though the scripts are written for a COSMOS environment, they require little to no translation for use in a MS-SQL environment.

-------------

Files:

preprocess1.script - preprocessing for data locality in distributed COSMOS environment

preprocess2.script - preprocessing for data locality in distributed COSMOS environment (runs after preprocess1.script)

compute-sindex.script - computes paper, author and venue s-index scores by leveraging iterative sparse matrix-vector multiplication via fast, data-aware joins

sindex_fast.m - computes paper s-index using iterative sparse matrix-vector multiplication over a paper-paper citation network stored in variable "A"


