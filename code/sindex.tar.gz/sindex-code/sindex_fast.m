v = ones(size(A,1),1);
scoresfast = sparse(size(A,1),1);

for i = 1:4
	disp(i)
	v = A*v;
	scoresfast = scoresfast + 2^(-i) * v;
end